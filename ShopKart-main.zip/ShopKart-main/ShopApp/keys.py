MID = ""
MK = ""